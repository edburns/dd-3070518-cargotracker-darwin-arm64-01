# Unclassified Campaign Evidence

- **Arm:** `treatment`
- **Evaluator:** `0.4.4` at `f76ebf2cf6a47ee4e86c630040ee5e85eb9e6c0e`

## event-0018 — task #2, stage 30

- Kind: `failed_ci_check`
- Detection gate: `null`
- Reason: The failing CI job was identified, but no failing step was captured.
- Artifact: `phase1-task-20261002-141418-2.md:773`

```text
<details>
<summary>19 lines</summary>

```
Refreshing checks status every 10 seconds. Press Ctrl+C to quit.

Shepherd task Cargo Tracker	pending	0	https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37019709398/job/110879713507	
formatting	pending	0	https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37019709124/job/110879724559	
Refreshing checks status every 10 seconds. Press Ctrl+C to quit.

Shepherd task Cargo Tracker	pending	0	https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37019709398/job/110879713507	
formatting	pending	0	https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37019709124/job/110879724559	
Refreshing checks status every 10 seconds. Press Ctrl+C to quit.

Shepherd task Cargo Tracker	pending	0	https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37019709398/job/110879713507	
formatting	pending	0	https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37019709124/job/110879724559	
Refreshing checks status every 10 seconds. Press Ctrl+C to quit.

formatting	fail	24s	https://github.com
…
```

## event-0027 — task #3, stage 30

- Kind: `failed_ci_check`
- Detection gate: `null`
- Reason: The failing CI job was identified, but no failing step was captured.
- Artifact: `phase1-task-20261002-145748-3.md:824`

```text
<details>
<summary>27 lines</summary>

```
[
  {
    "name": "build",
    "status": "completed",
    "conclusion": "skipped",
    "details_url": "https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37024901644/job/110897629481"
  },
  {
    "name": "source-gates",
    "status": "completed",
    "conclusion": "skipped",
    "details_url": "https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37024901644/job/110897627603"
  },
  {
    "name": "formatting",
    "status": "completed",
    "conclusion": "failure",
    "details_url": "https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37024901644/job/110897430500"
  },
  {
    "name": "Shepherd task Cargo Tracker",
    "status": "completed",
    "conclusion": "success",
    "details_url": "https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37024901014/job/110897429765"
  }
]
<shellId: 12 completed with exit code 7>
```

</details>
```

## event-0029 — task #3, stage 30

- Kind: `failed_ci_check`
- Detection gate: `null`
- Reason: The failing CI job was identified, but no failing step was captured.
- Artifact: `phase1-task-20261002-145748-3.md:1144`

```text
<details>
<summary>27 lines</summary>

```
[
  {
    "name": "build",
    "status": "completed",
    "conclusion": "failure",
    "details_url": "https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37025616663/job/110900663192"
  },
  {
    "name": "source-gates",
    "status": "completed",
    "conclusion": "success",
    "details_url": "https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37025616663/job/110900148370"
  },
  {
    "name": "Shepherd task Cargo Tracker",
    "status": "completed",
    "conclusion": "success",
    "details_url": "https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37025616732/job/110899945195"
  },
  {
    "name": "formatting",
    "status": "completed",
    "conclusion": "success",
    "details_url": "https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37025616663/job/110899936447"
  }
]
<shellId: 18 completed with exit code 7>
```

</details>
```

## event-0032 — task #3, stage 30

- Kind: `nonzero_tool_exit`
- Detection gate: `null`
- Reason: No deterministic product, operational, or infrastructure rule matched.
- Artifact: `phase1-task-20261002-145748-3.md:1760`

```text
```
jq: error: $sub is not defined at <top-level>, line 1:
{head:$head,state:$state,draft:$draft,base:$base,latestWorkStarted:$start,latestWorkFinished:$finish,changedFiles:$changed,fileCount:$files,reviewDecision:$decision,unresolvedThreads:$unresolved,pendingChecks:$pending,failingChecks:$failing,substantiveSuccessfulChecks:$sub,headStable:true}                                                                                                                                                                                                                                                                             
jq: 1 compile error
<shellId: 32 completed with exit code 3>
```
```

## event-0009 — task #4, stage 30

- Kind: `failed_ci_check`
- Detection gate: `null`
- Reason: The failing CI job was identified, but no failing step was captured.
- Artifact: `phase1-task-20261002-155708-4.md:1697`

```text
<details>
<summary>68 lines</summary>

```
Refreshing checks status every 10 seconds. Press Ctrl+C to quit.

Shepherd task Cargo Tracker	pending	0	https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37031874286/job/110921056475	
formatting	pending	0	https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37031874226/job/110921050813	
Refreshing checks status every 10 seconds. Press Ctrl+C to quit.

Shepherd task Cargo Tracker	pending	0	https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37031874286/job/110921056475	
formatting	pending	0	https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37031874226/job/110921050813	
Refreshing checks status every 10 seconds. Press Ctrl+C to quit.

Shepherd task Cargo Tracker	pending	0	https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37031874286/job/110921056475	
formatting	pending	0	https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37031874226/job/110921050813	
Refreshing checks status every 10 seconds. Press Ctrl+C to quit.

Shepherd task Cargo Tracker	pending	0	
…
```

## event-0001 — task #5, stage 30

- Kind: `failed_ci_check`
- Detection gate: `null`
- Reason: The failing CI job was identified, but no failing step was captured.
- Artifact: `phase1-task-20261002-171627-5.md:1159`

```text
<details>
<summary>68 lines</summary>

```
Refreshing checks status every 10 seconds. Press Ctrl+C to quit.

Shepherd task Cargo Tracker	pending	0	https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37042014289/job/110954847705	
formatting	pending	0	https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37042014142/job/110954844377	
Refreshing checks status every 10 seconds. Press Ctrl+C to quit.

Shepherd task Cargo Tracker	pending	0	https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37042014289/job/110954847705	
formatting	pending	0	https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37042014142/job/110954844377	
Refreshing checks status every 10 seconds. Press Ctrl+C to quit.

source-gates	pending	0	https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37042014142/job/110955023267	
formatting	pass	24s	https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs/37042014142/job/110954844377	
Shepherd task Cargo Tracker	pending	0	https://github.com/edburns/dd-3072707-tricket-out-cargotracker-run-03/actions/runs
…
```

## event-0005 — task #5, stage 30

- Kind: `nonzero_tool_exit`
- Detection gate: `null`
- Reason: No deterministic product, operational, or infrastructure rule matched.
- Artifact: `phase1-task-20261002-171627-5.md:2168`

```text
```
Traceback (most recent call last):
  File "<stdin>", line 20, in <module>
AssertionError
<shellId: 36 completed with exit code 1>
```
```

## event-0006 — task #5, stage 30

- Kind: `nonzero_tool_exit`
- Detection gate: `null`
- Reason: No deterministic product, operational, or infrastructure rule matched.
- Artifact: `phase1-task-20261002-171627-5.md:2363`

```text
```
Traceback (most recent call last):
  File "<stdin>", line 20, in <module>
AssertionError
<shellId: 43 completed with exit code 1>
```
```

## event-0007 — task #5, stage 30

- Kind: `nonzero_tool_exit`
- Detection gate: `null`
- Reason: No deterministic product, operational, or infrastructure rule matched.
- Artifact: `phase1-task-20261002-171627-5.md:3171`

```text
```

<shellId: 66 completed with exit code 1>
```
```

## event-0013 — task #5, stage 40

- Kind: `nonzero_tool_exit`
- Detection gate: `null`
- Reason: No deterministic product, operational, or infrastructure rule matched.
- Artifact: `phase2-task-20261002-182521-5.md:1214`

```text
```
{"baseRefName":"edburns/dd-3016202-cargotracker-devoxx-be-2026-add-feature-control","headRefOid":"a4ed0b3dde3676f5880052db65fe2e729d32e7f0","isDraft":false,"mergeable":"MERGEABLE","state":"OPEN"}
unresolved_threads=0
no required checks reported on the 'copilot/44-implement-primefaces-deadline-dialog' branch
<shellId: 5 completed with exit code 1>
```
```

